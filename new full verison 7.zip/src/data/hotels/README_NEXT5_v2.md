Next 5 hotels/guesthouses/sanatoriums added as individual JSON files with real contact phones. Images are demo/stock.
