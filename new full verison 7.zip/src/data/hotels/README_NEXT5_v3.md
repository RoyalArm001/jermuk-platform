Next 5 Jermuk hotels/resorts added as individual JSON files with phone numbers when available. Images are demo/stock.
