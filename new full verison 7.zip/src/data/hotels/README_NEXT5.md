Next 5 hotels added as individual files (named). Run your merge script to rebuild hotels.json.
