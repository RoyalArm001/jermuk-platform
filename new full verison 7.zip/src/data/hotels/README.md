# Hotels TOP-5 (Phase 1)

- `src/data/hotels.json` is the merged list used by the app now.
- `src/data/hotels_top5/*.json` are the same items, split per-hotel so you can edit/update one hotel without touching the others.

After editing an individual file, copy its JSON object back into `src/data/hotels.json` (or you can automate merge later).
